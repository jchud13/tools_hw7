/****************************************
The main for part 3 of the game
By Jared Chudzinski
very simple, declares the board
then plays the first move
uses namespace standard
***************************************/



#include <iostream>

#include "game.h"
#include "othello.h"

using namespace main_savitch_14;

int main(){
	Othello first;
	first.play();
	return 0;
}